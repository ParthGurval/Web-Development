// var myFirstName; // Variable Declaration
// myName = "Parth"; // Variable Assignment or Initialization

// console.log(myName);

// var city = "Pune"; // Variable Declaration and Initialization
// console.log(city);

// var pin; // Variable Declaration
// console.log(pin);

var salary = null;
console.log("Type of variable salary is:",typeof salary);
salary = 50000.50;
console.log(typeof salary);