//Wed 19-07-2023

//JS Assignment No.01 

//Part1
var myFullName;
console.log("type of variable myFullName is:" + typeof myFullName);
myFullName = "Parth Guurval";
console.log("My First & Last name is:" + myFullName);
myFullName = "Parth Vinayak Gurval"
console.log("My Full Name is:" + myFullName);

//Part2
var myLove = "I Love Only JS"
console.log(myLove);


//Part3
var firstName = "Parth";
console.log("First-name:" + firstName);
var lastName = "Gurval";
console.log("Last Name:" + lastName);
var age = 22;
console.log("Age:" + age);
var address = "Wakad Pune";
console.log("Address:" + address);
var pinCode = "411057"
console.log("Pincode:" + pinCode);
var gender = "Male"
console.log("Gender:" + gender);
var isMarried = "False"
console.log("Married Status:" + isMarried);