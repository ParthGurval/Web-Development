var firstName="Parth";
var age= 21;
var isMarried= true;
var city="Pune";
city=5000;
console.log(city);
console.log(typeof city);

console.log('=======================================');
var salary = null;
console.log(typeof salary);
salary = 40000.50; // 
var typeOfSalary = typeof salary;
console.log('salary=>', salary, 'typeof salary =>', typeOfSalary);
salary = "Forty Thousand";
var salaryTypeOf = typeof salary;
console.log('salary=>', salary, 'typeof=>', salaryTypeOf);

