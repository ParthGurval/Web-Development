// 19-07-2023

//Assignment No:2

//part-1
var bankName;
console.log("Type of variable bankName is:" + typeof bankName);
bankName = "SBI Bank";
console.log("Bank Name is:" + bankName);
console.log("Type of variable bankName is:" + typeof bankName);

//part-2
var marks = '90%';
console.log("Marks are:" + marks);
console.log("Type of variable marks is:" + typeof marks);

//part-3
var isWorking
console.log("Type of variable isWorking is:" + typeof isWorking);
isWorking = true;
console.log("Is-Working:" + isWorking);
console.log("Type of isWorking is:" + typeof isWorking);

//part-4
var totalCount = "Hundred and Seven";
console.log("Value is:" + totalCount);
console.log("Type of variable totalCount is:" + typeof totalCount);
totalCount = 107;
console.log("Change Value is:" + totalCount);
console.log("Type of variable totalCount is:" + typeof totalCount);