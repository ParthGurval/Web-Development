
console.log("========================== ASSIGNMENT NO. 1 ========================");


function stringBasics() {

    console.log("\----------------------------Step 1----------------------------/");

    console.log(`My Dream Companey is Apple Inc.`);

    console.log("\----------------------------Step 1----------------------------/");

    var hobby1 = "Car Racing";
    var hobby2 = "Watching Movies in theater"
    var hobby3 = "UI/UX Designing"

    console.log(`My Hobbies are: `, hobby1, " | | ", hobby2, " | | ", hobby3);

    // Step 3: Calculate the total number of characters in all hobbies and log on the console

    var totalCharacters = hobby1.length + hobby2.length + hobby3.length;

    console.log("The Total Numbers of character in all hobbies are: ", totalCharacters);
}

stringBasics();

