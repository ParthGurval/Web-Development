
console.log(`/__________________________ Assignment No. 01 _________________________________/`);
console.log('');

console.log(`------------------ STEP-I -------------------------`);
console.log('"WAP to print no. from 5 to 15 by incrementing 1"');
for (let i = 5; i <= 15; i++) {
    
    console.log(`The Numbers are: ${i}`);
}


console.log(`------------------ STEP-II -------------------------`);
console.log('"WAP to print no. from 50 to 40 by decrementing by 1"');
for (let i = 50; i >= 40; i--) {
    
    console.log(`The Numbers are: ${i}`);
}

console.log(`------------------ STEP-III -------------------------`);
console.log('"WAP to print first 15 Odd numbers"');
for (let i = 1; i <= 30; i=i+2) {
    
    console.log(`The Odd Number is: ${i}`);
}

console.log(`------------------ STEP-IV -------------------------`);
console.log('"WAP to print first 10 even numbers"');
for (let i = 0; i <= 19; i=i+2) {
    
    console.log(`The Even Number is: ${i}`);
}

console.log(`------------------ STEP-V -------------------------`);
console.log('"WAP to print Table of 5"');
for (let i = 5; i <= 50; i=i+5) {
    
    console.log(`Table of 5: ${i}`);
}

console.log(`------------------ STEP-VI -------------------------`);
console.log('"WAP to print Table of 10"');
for (let i = 10; i <= 100; i=i+10) {
    
    console.log(`Table of 10: ${i}`);
}

console.log(`------------------ STEP-VI -------------------------`);
console.log('"WAP to print Table of 10 in reverse"');
for (let i = 100; i >= 10; i=i-10) {
    
    console.log(`Reverse Table of 10: ${i}`);
}

console.log(`============================= End Of Code ====================================`);