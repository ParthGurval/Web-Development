

var result =  (10 == '10');
console.log(typeof result);
console.log(`Given Values are: 0 == ''`);
console.log(`Result is: ${result}`);

var result = (0 == '0');
console.log(`Given Values: 0 == '0'`);
console.log(`Result is: ${result}`);