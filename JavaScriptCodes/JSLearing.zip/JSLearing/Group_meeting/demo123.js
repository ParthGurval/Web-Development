
;var a = 2
;var b = 3

;var res = a+b

console.log(res);