

let mapping = new Map();

mapping.set("Name", "Kiran")
mapping.set("Roll No", 1);
mapping.set("ID", 1111);
mapping.set("FName", "Kiran");
mapping.set("LName", "Swami");
mapping.set("Phone", 6554321321);
mapping.set("Gender", "Male");

console.log(mapping);

console.table(mapping);

console.log(mapping.size);