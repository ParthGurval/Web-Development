

// var str = "Hello I'm Siri";
// var strLength = str.length;

// console.log(str, 'Length of given String is:', strLength);

// var charAtValue = str.charAt(7);
// console.log(`${str} - char at 0th position is: ${charAtValue}`);

// var charLast = str.charAt(strLength-1);
// console.log(` Last Character is ${charLast} of index value is: ${strLength}`);

// var num = 100;
// console.log(num);
// var display = function(){
//     console.log(`I am Angular Developer !`);
// }
// display();
// console.log(typeof display);

