const randomNumber1 = Math.random();
const randomNumber2 = Math.random();

console.log(`Random number 1: ${randomNumber1}`);
console.log(`Random number 2: ${randomNumber2}`);


// const names = ['Alice', 'Bob', 'Charlie', 'David', 'Eve'];
// const numbers = [1, 2, 3, 4, 5];

// const result = {};

// for (let i = 0; i < names.length; i++) {
//   const index = i % numbers.length;
//   result[names[i]] = numbers[index];
// }

// console.log(result);

// arr = [1, 2, 3, 4, 5];

// console.log(arr);

// for (let i = 0; i < arr.length; i++) {
//     const element = arr[i];
//     console.log(element);
// }   


