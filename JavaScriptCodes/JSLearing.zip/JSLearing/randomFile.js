

const randomNumber = Math.random();

console.log(randomNumber);


const floorNum = Math.floor(8.7526);
console.log(floorNum);