

let num = 1;

while(num <= 10){

    let result = num *5;
    console.log(result);

    num++;
}


