


// const multArray = [[1,2], [3,4], [5,6]];

// const useReduce = multArray.reduce((accumulator, currVal) => {

//     return accumulator.concat(currVal);
// }, []);

// console.log(useReduce);


// const arrNum = [10, 5, 22, 56, 85, 75];

// const max = arrNum.reduce((accmu, currVal)=> Math.max(accumulator))

// console.log("hello".toUpperCase());

const x = 10;
if (x > 5) { const x = 5;  console.log(x);}